CSV FILES — SMART IRRIGATION PROJECT (UP)

Is folder mein:
1. crop_soil_master_template.csv — 3 crops × 3 soil types ka master CSV.
2. wheat_data_template.csv — Wheat ke liye 3 soil categories.
3. maize_data_template.csv — Maize ke liye 3 soil categories.
4. potato_data_template.csv — Potato ke liye 3 soil categories.
5. weather_soil_observations_template.csv — real weather/soil-moisture observations ke liye blank CSV.
6. crop_soil_combinations.csv — crop aur soil combinations.

IMPORTANT:
Temperature, humidity, rainfall aur soil moisture ke cells abhi blank hain.
Inmein fake values nahi bhari gayi hain. Real values Open-Meteo Historical Weather API se
download karni hongi. Soil type labels abhi requested scenario categories hain, verified
farm-level soil tests nahi. irrigation_required ko bhi bina verified labels/rule ke fill na karein.
